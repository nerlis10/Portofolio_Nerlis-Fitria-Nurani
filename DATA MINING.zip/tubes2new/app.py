import streamlit as st
import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Load the trained models
classifier_model = joblib.load(open('heart_disease_model.pkl', 'rb'))
clustering_model = joblib.load(open('kmeans_model.pkl', 'rb'))
scaler = joblib.load(open('scaler.pkl', 'rb'))
pca = joblib.load(open('pca_model.pkl', 'rb'))

# StandardScaler instance (used in preprocessing)

def preprocess_input(data):
    """
    Preprocess the input data using the same pipeline as the training phase.
    """
    data['sex'] = data['sex'].replace({'Male': 1, 'Female': 0})
    data['dataset'] = data['dataset'].replace({
        'Hungary': 0,
        'Cleveland': 1,
        'VA Long Beach': 2,
        'Switzerland': 3
    })
    data['cp'] = data['cp'].replace({
        'atypical angina': 0,
        'non-anginal': 1,
        'typical angina': 2,
        'asymptomatic': 3
    })
    data['fbs'] = data['fbs'].replace({'True': 1, 'False': 0})
    data['restecg'] = data['restecg'].replace({
        'normal': 0,
        'lv hypertrophy': 1,
        'st-t abnormality': 2
    })
    data['exang'] = data['exang'].replace({'False': 0, 'True': 1})

    # Scale features
    scaled_features = scaler.transform(data)
    return scaled_features

def apply_pca(df_clustering):
    pca_features = pca.transform(df_clustering)
    pca_df = pd.DataFrame(pca_features, columns=['pca1', 'pca2'])
    return pca_df

# Streamlit App Title
st.title("Heart Disease Prediction and Clustering App")

# User Inputs
st.header("Input Features")

def user_input_features():
    age = st.number_input('Age', min_value=20, max_value=80, value=50, step=1)
    sex = st.selectbox('Sex', ['Male', 'Female'])
    origin = st.selectbox('Origin', ['Hungary', 'Cleveland', 'VA Long Beach', 'Switzerland'])
    cp = st.selectbox('Chest Pain Type', ['typical angina', 'atypical angina', 'non-anginal', 'asymptomatic'])
    trestbps = st.number_input('Resting Blood Pressure (mm Hg)', min_value=80, max_value=200, value=120, step=1)
    chol = st.number_input('Serum Cholesterol (mg/dl)', min_value=100, max_value=400, value=200, step=1)
    fbs = st.selectbox('Fasting Blood Sugar > 120 mg/dl', ['True', 'False'])
    restecg = st.selectbox('Resting Electrocardiographic Results', ['normal', 'lv hypertrophy', 'st-t abnormality'])
    thalch = st.number_input('Maximum Heart Rate Achieved', min_value=60, max_value=220, value=150, step=1)
    exang = st.selectbox('Exercise-Induced Angina', ['True', 'False'])
    oldpeak = st.number_input('ST Depression Induced by Exercise', min_value=0.0, max_value=6.0, value=1.0, step=0.1)

    data = {
        'age': age,
        'sex': sex,
        'dataset': origin,
        'cp': cp,
        'trestbps': trestbps,
        'chol': chol,
        'fbs': fbs,
        'restecg': restecg,
        'thalch': thalch,
        'exang': exang,
        'oldpeak': oldpeak
    }

    return pd.DataFrame(data, index=[0])


input_data = user_input_features()

# Prediction and Clustering Button
if st.button("Predict and Cluster"):
    # Preprocess Input
    processed_input = preprocess_input(input_data)

    # Make Prediction
    prediction = classifier_model.predict(processed_input)
    probability = classifier_model.predict_proba(processed_input)[0][1]

    # Display Prediction
    st.subheader("Prediction")
    if prediction[0] == 1:
        st.write("The model predicts that the patient **has heart disease**.")
    else:
        st.write("The model predicts that the patient **does not have heart disease**.")

    st.subheader("Prediction Probability")
    st.write(f"Probability of heart disease: {probability:.2f}")

    # Clustering Section
    st.subheader("Clustering Analysis")
    # Extract relevant columns for clustering
    clustering_input = input_data[['age', 'sex', 'dataset', 'chol', 'thalch', 'oldpeak']].copy()
    scaled_clustering_input = scaler.fit_transform(clustering_input)
    # Perform PCA and clustering
    pca_df = apply_pca(scaled_clustering_input)
    cluster_labels = clustering_model.predict(pca_df)
    pca_df['Cluster'] = cluster_labels

    st.write("Cluster Assignment : " + str(cluster_labels[0]))



